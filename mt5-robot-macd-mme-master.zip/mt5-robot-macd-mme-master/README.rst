mt5-robot-macd-mme
==================

MetaTrader 5 Trading Robot - MACD and Crossing Exponential Moving Average


TODO
====
Modules to develop:
 - ExpertDax
 - TrailingStopPercent:

TrailingStopPercent:
 - smart trailing stop that allows N % on retracement after a fixed treshold. Once this profit-side treshold is crossed, stop loss is placed to N % of gain. 
